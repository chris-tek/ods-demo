import boto3

def lambda_handler(event, context):
    
    source_bucket = 'chris-ijames-test-bucket-2'
    destination_bucket = 'chris-ijames-bucket'
    
    s3 = boto3.resource('s3')
    objects = list(s3.Bucket(source_bucket).objects.all())
    info = ""
    
    for s3_object in objects:
        key = s3_object.key
        bucket_name = s3_object.bucket_name
        folder_structure = key
        copy_source = {
            'Bucket': bucket_name,
            'Key': key
        }
        info += "Copying s3://" + destination_bucket + "/" + folder_structure + "\n"
        s3.meta.client.copy(copy_source, destination_bucket, folder_structure)
    return info